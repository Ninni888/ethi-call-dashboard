import React from "react";

const RisultatoFinale = () => {
  return (
    <div>
      <h1>Risultato Finale</h1>
      <p>
        Qui verrà mostrato il punteggio totale e la valutazione finale
        dell'assessment.
      </p>
    </div>
  );
};

export default RisultatoFinale;
